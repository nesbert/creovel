<?php
class application_controller extends controller
{

}
?>