<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

	<?=stylesheet_include_tag(array('creovel'))?>
	<link rel="SHORTCUT ICON" href="/images/favicon.ico">
	
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>creovel - A PHP Framework</title>
	
</head>

<body>

<div id="wrapper">

	<div id="header">
		<p class="name"><strong>creo</strong><em>vel</em><br /></p>
		<p>A PHP Framework.</p>
	</div>
	
	<div id="content">
	
	@@page_contents@@
	
	</div>
	
	<div id="footer">
		<p class="legal"><strong>Disclaimer:</strong> legal shit...</p>
	</div>
	
</div>

</body>
</html>