<?php

/**
 *  This file calls the event and creates the page to be displayed. Created on 10/20/2005.
 * 
 * @copyright Copyright (c) 2005, creovel.org
 * @package creovel
 *
 *
 */

require_once('../config/environment.php');

creovel();
?>
